
public class TestRenctangle {


	public static void main(String[] args) {
		// Create two objects of this class, r1 and r2. Show the output of both the
		// constructor sand all method of these two objects
		Rectangle r1 = new Rectangle();
		Rectangle r2 = new Rectangle(8, 8);
		r1.printData();
		r1.printArea();
		r1.printPerimeter();


		r2.printData();
		r2.printArea();
		r2.printPerimeter();
		;


	}
}