
public class Exp6_1
{
 public static void main(String[] args) 
 {
  BookInfo ob1 = new BookInfo("James Gosling", "Java Programming", "Techpress", 350.50F, 10);
  BookInfo ob2 = new BookInfo("Dennis Ritchie", "C Language", "Prentice Hall", 200.50F, 20);
  BookInfo ob3 = new BookInfo("Bjarne Stroustrup","C++ Programming  Language", "Pearson Publication", 250.50F, 15);
  ob1.show();
  ob2.show();
  ob3.show();
 }
}